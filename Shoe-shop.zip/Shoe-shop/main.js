const express = require('express');
const cors = require('cors');
const app = express();
const port = 4000;

/* CROS middleware */
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  next();
});
// parse data to json when call api
app.use(express.json());
app.listen(port, function () {
  console.log("Server is running on " + port + " port");
});