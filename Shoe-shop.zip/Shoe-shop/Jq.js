var angle = 0;
function galleryspin(sign) { 
spinner = document.querySelector("#spinner");
if (!sign) 
	{
		 angle = angle + 45; 
	} 
	else 
		{
		 	angle = angle - 45;
		}

spinner.setAttribute(
	"style","-webkit-transform: rotateY("+ angle +"deg); -moz-transform: rotateY("+ angle +"deg); transform: rotateY("+ angle +"deg);");
};
$(document).ready(function(){
	$('.best-seller-menu nav ul li:nth(0)').addClass("active");
	$('.best-seller-product #list').each(function() {
			if($(this).hasClass("new-product"))
			{
				$(this).removeClass('hidden');
				$(this).addClass('setPosition');
			}
			else
			{
				$(this).addClass('hidden');
				$(this).removeClass('setPosition');

			}
	});

	var last_position='.best-seller-menu nav ul li:nth(0)'
	$('.best-seller-menu nav ul li').click(function(event) {
		/* Act on the event */
		var _type= $(this).data('class');
		$(this).addClass("active");
		$(last_position).removeClass("active");
		last_position=$(this);
		$('.best-seller-product #list').each(function() {
			if($(this).hasClass(_type))
			{
				$(this).removeClass('hidden');
				$(this).addClass('setPosition');
			}
			else
			{
				$(this).addClass('hidden');
				$(this).removeClass('setPosition');
			}
		});
		
		return false;
	});
});